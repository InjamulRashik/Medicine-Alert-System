
package medalart;


public class MainClass {

    public static void main(String[] args) {
     
        FirstFrame ff = new FirstFrame();
        ff.setVisible(true);
    }
    
}
