/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medalart;

import java.sql.DriverManager;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author student
 */
public class DBConnect {
    private Connection con;
    private Statement st;
    private ResultSet rs;
    
    public DBConnect(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/medreminder","root", "");
    
    
            st = con.createStatement();
    
        } catch (Exception e) {
        System.out.println("Error : "+e);
        e.printStackTrace();
        }
    }
    
    public ResultSet getResultSet() {
        try {
    String query = "select userid               ";
    
            rs = st.executeQuery(query);
            
        } catch (Exception e) {
            System.out.println("Error : "+ e);
            e.printStackTrace();
            
        }
        return rs;
    }
    
   
   public void insertIntoDB(ArrayList row) {
       try {
           String query = "INSERT INTO `userinfo`(`UserID`, `UserName`, `Age`) VALUES ('" +
                   row.get(0) + "','" + row.get(1) + "','" + row.get(2) + "'"+");";
                   
         System.out.println(query);
           st.executeUpdate(query);
           JOptionPane.showMessageDialog(null, "User Information Added Successfully");
           
       }
       catch (SQLException e){
           JOptionPane.showMessageDialog(null, "Insert into Database Exception : "+e);
           System.out.println("from insert into db " + e);
       }
   }
   
   public void insertIntoMed(ArrayList<String> row){
       
        try {
            String sql_q = "INSERT INTO `medinfo`(`UserID`, `MedName`, `Morning`, `Noon`, `Night`) VALUES (?,?,?,?,?)";
            
            PreparedStatement stmt = con.prepareStatement(sql_q);
            stmt.setString(1, row.get(0));
            stmt.setString(2, row.get(1));

            if(row.get(2) != null){
                stmt.setString(3, row.get(2));
            }
            else {
                stmt.setNull(3, Types.TIME);
            }
            if(row.get(3) != null){
                stmt.setString(4, row.get(3));
            }
            else {
                stmt.setNull(4, Types.TIME);
            }
            if(row.get(4) != null){
                stmt.setString(5, row.get(4));
            }
            else {
                stmt.setNull(5, Types.TIME);
            }

            int i = stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Med Info Successfully");
        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(null, "here Insert into Database Exception : "+e);
            System.out.println("from insert into db " + e);
        }
          
   }
   
   public ResultSet getAnswer(String query){
       ResultSet ans = null;
       
       try{
           ans = st.executeQuery(query);
       } catch (SQLException e) {
           System.out.println("from getAnswer " + e);
       }
       return ans;
   }  
}