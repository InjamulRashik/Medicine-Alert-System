-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2018 at 05:14 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medreminder`
--

-- --------------------------------------------------------

--
-- Table structure for table `medinfo`
--

CREATE TABLE `medinfo` (
  `UserID` varchar(100) NOT NULL,
  `MedName` varchar(100) NOT NULL,
  `Morning` time DEFAULT NULL,
  `Noon` time DEFAULT NULL,
  `Night` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medinfo`
--

INSERT INTO `medinfo` (`UserID`, `MedName`, `Morning`, `Noon`, `Night`) VALUES
('admin1234', 'gas', '07:00:00', '13:00:00', NULL),
('admin1234', 'xx', NULL, NULL, NULL),
('rashik', 'Napa', '15:59:00', NULL, NULL),
('tester1', 'chuku', '18:03:00', NULL, NULL),
('tester1', 'gas', NULL, NULL, NULL),
('tester1', 'kala', '07:00:00', NULL, NULL),
('tester1', 'sdhifhdsof', '07:00:00', NULL, NULL),
('tester1', 'xxxx', '07:00:00', NULL, NULL),
('tester1', 'xxxxxx', '17:52:00', NULL, NULL),
('tester1', 'yolo', '17:52:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `UserID` varchar(100) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Age` int(11) NOT NULL,
  `Gender` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`UserID`, `UserName`, `Age`, `Gender`) VALUES
('admin1234', 'tarik hassan', 22, NULL),
('Kabbo', 'kabbo123', 22, NULL),
('Meem', 'meem12', 21, NULL),
('Rashik', 'rashik12', 22, NULL),
('Tarik Hassan', 'admin1234', 22, NULL),
('Test', 'test1', 24, NULL),
('Test1', 'test2', 22, NULL),
('tester1', 'mr tester', 22, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medinfo`
--
ALTER TABLE `medinfo`
  ADD PRIMARY KEY (`UserID`,`MedName`) USING BTREE;

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `UserID` (`UserID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `medinfo`
--
ALTER TABLE `medinfo`
  ADD CONSTRAINT `medinfo_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `userinfo` (`UserID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
